# Testing

The `:std/test` library provides a lightweight testing framework.

::: tip usage
(import :std/test)
:::

## Overview

Please write me!

## Interface

### test-suite
::: tip usage
```
(test-suite ...)
```
:::

Please document me!

### test-case
::: tip usage
```
(test-case ...)
```
:::

Please document me!

### check
::: tip usage
```
(check ...)
```
:::

Please document me!

### checkf
::: tip usage
```
(checkf ...)
```
:::

Please document me!

### check-eq?
::: tip usage
```
(check-eq? ...)
```
:::

Please document me!

### check-not-eq?
::: tip usage
```
(check-not-eq? ...)
```
:::

Please document me!

### check-eqv?
::: tip usage
```
(check-eqv? ...)
```
:::

Please document me!

### check-not-eqv?
::: tip usage
```
(check-not-eqv? ...)
```
:::

Please document me!

### check-equal?
::: tip usage
```
(check-equal? ...)
```
:::

Please document me!

### check-not-equal?
::: tip usage
```
(check-not-equal? ...)
```
:::

Please document me!

### check-output
::: tip usage
```
(check-output ...)
```
:::

Please document me!

### check-predicate
::: tip usage
```
(check-predicate ...)
```
:::

Please document me!

### check-exception
::: tip usage
```
(check-exception ...)
```
:::

Please document me!

### !check-fail?
::: tip usage
```
(!check-fail? ...)
```
:::

Please document me!

### !check-fail-e
::: tip usage
```
(!check-fail-e ...)
```
:::

Please document me!

### run-tests!
::: tip usage
```
(run-tests! ...)
```
:::

Please document me!

### test-report-summary!
::: tip usage
```
(test-report-summary! ...)
```
:::

Please document me!

### run-test-suite!
::: tip usage
```
(run-test-suite! ...)
```
:::

Please document me!

### test-result
::: tip usage
```
(test-result ...)
```
:::

Please document me!

## Example

Please write me!