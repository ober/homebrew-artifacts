#!/usr/bin/env bash

cd ${0%/*}

npm install
npm run build
